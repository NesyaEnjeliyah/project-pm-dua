================================================================
  LANGKAH-LANGKAH MENJALANKAN SISTEM PAKAR PENYAKIT LAMBUNG
  Sistem Pakar Diagnosis Dini Penyakit Lambung
================================================================
 
STRUKTUR PROYEK
---------------
FIX_PROJECT/
├── static/
│   ├── css/
│   │   └── style.css
│   └── js/
│       ├── diagnosis.js
│       └── main.js
├── templates/
│   ├── base.html
│   ├── diagnosis.html
│   ├── index.html
│   ├── riwayat.html
│   └── tentang.html
├── app.py
├── requirements.txt
└── riwayat.db  ← dibuat otomatis saat app pertama dijalankan
 
 
================================================================
  LANGKAH 1 — INSTALL FLASK
================================================================
 
Buka terminal / command prompt, lalu jalankan:
 
    pip install flask
 
Perintah ini menginstal framework Flask yang dibutuhkan
sebagai web server aplikasi Python.
 
 
================================================================
  LANGKAH 2 — INSTALL SEMUA DEPENDENSI
================================================================
 
Kemudian jalankan:
 
    pip install -r requirements.txt
 
================================================================
  LANGKAH 3 — JALANKAN APLIKASI
================================================================
 
Masih di dalam folder proyek, jalankan:
 
    python app.py
 
Output yang diharapkan di terminal:
 
    * Running on http://127.0.0.1:5000
    * Debug mode: on  (atau off)
 
Kemudian buka browser dan akses:
 
    http://127.0.0.1:5000
    atau
    http://localhost:5000
 
Catatan:
- File riwayat.db akan dibuat OTOMATIS di folder proyek
  pada saat pertama kali aplikasi dijalankan.
- Jangan tutup terminal selama aplikasi berjalan.
- Untuk menghentikan aplikasi, tekan CTRL + C di terminal.
 
 
================================================================
  RINGKASAN PERINTAH (URUTAN LENGKAP)
================================================================
 
    pip install flask
    pip install -r requirements.txt
    python app.py
 
 
================================================================
  HALAMAN YANG TERSEDIA
================================================================
 
  http://localhost:5000/             → Halaman utama
  http://localhost:5000/diagnosis    → Halaman konsultasi
  http://localhost:5000/riwayat      → Riwayat diagnosis
  http://localhost:5000/tentang      → Tentang sistem