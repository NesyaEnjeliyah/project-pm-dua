// ============================================================
// 3G-CARE — DIAGNOSIS JS
// ============================================================

// ELEMEN DOM
const diagnosisForm = document.getElementById('diagnosisForm');
const gejalaCheckboxes = document.querySelectorAll('.gejala-checkbox');
const selectedCountEl = document.getElementById('selectedCount');
const progressFill = document.getElementById('progressFill');
const submitBtn = document.getElementById('submitBtn');
const submitText = document.getElementById('submitText');
const resetBtn = document.getElementById('resetBtn');
const searchGejala = document.getElementById('searchGejala');
const gejalaCards = document.querySelectorAll('.gejala-card');
const modalOverlay = document.getElementById('modalOverlay');
const modalClose = document.getElementById('modalClose');
const loadingState = document.getElementById('loadingState');
const hasilState = document.getElementById('hasilState');
const diagnosisUlangBtn = document.getElementById('diagnosisUlangBtn');

// STATE
let selectedGejala = [];
let hasilData = null;

// ============================================================
// UPDATE PROGRESS
// ============================================================
function updateProgress() {
    selectedGejala = [];
    gejalaCheckboxes.forEach(cb => {
        if (cb.checked) selectedGejala.push(cb.value);
    });

    const count = selectedGejala.length;
    const total = 28;
    const pct = (count / total)*100;

    selectedCountEl.textContent = count;
    progressFill.style.width = pct + '%';

const warningLama = document.getElementById('warningMinimal');
if (warningLama) warningLama.remove();

if (count === 0) {
    submitBtn.disabled = true;
    submitText.textContent = 'Pilih minimal 3 gejala';

} else if (count === 1 || count === 2) {
    submitBtn.disabled = true;
    submitText.textContent = `Pilih minimal 3 gejala (${count} dipilih)`;

    const warning = document.createElement('div');
    warning.id = 'warningMinimal';
    warning.style.cssText = `
        background: #fffbeb;
        border: 1.5px solid #fcd34d;
        border-radius: 8px;
        padding: 0.6rem 1rem;
        font-size: 1rem;
        color: #78350f;
        font-weight: 500;
        margin-bottom: 0.75rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
        animation: fadeIn 0.2s ease;
    `;
    warning.innerHTML = `
        <span>⚠️</span>
        <span>Anda baru memilih <strong>${count} gejala</strong>. 
        Minimal <strong>3 gejala</strong> harus dipilih untuk melanjutkan diagnosis.</span>
    `;

    const progressWrap = document.querySelector('.progress-bar-wrap');
    progressWrap.insertAdjacentElement('afterend', warning);

} else {
    submitBtn.disabled = false;
    submitText.textContent = `Diagnosis (${count} gejala dipilih)`;
}
}

// ============================================================
// SEARCH GEJALA
// ============================================================
searchGejala.addEventListener('input', function () {
    const query = this.value.toLowerCase().trim();
    gejalaCards.forEach(card => {
        const nama = card.getAttribute('data-nama') || '';
        const kode = card.getAttribute('data-kode') || '';
        if (nama.includes(query) || kode.toLowerCase().includes(query)) {
            card.classList.remove('hidden');
        } else {
            card.classList.add('hidden');
        }
    });
});

// ============================================================
// CHECKBOX CHANGE
// ============================================================
gejalaCheckboxes.forEach(cb => {
    cb.addEventListener('change', updateProgress);
});

// ============================================================
// RESET
// ============================================================
resetBtn.addEventListener('click', function () {
    gejalaCheckboxes.forEach(cb => { cb.checked = false; });
    searchGejala.value = '';
    gejalaCards.forEach(card => card.classList.remove('hidden'));
    updateProgress();
});

// ============================================================
// MODAL OPEN / CLOSE
// ============================================================
function openModal() {
    modalOverlay.classList.add('active');
    document.body.style.overflow = 'hidden';
    loadingState.style.display = 'block';
    hasilState.style.display = 'none';
}

function closeModal() {
    modalOverlay.classList.remove('active');
    document.body.style.overflow = '';
}

modalClose.addEventListener('click', closeModal);
modalOverlay.addEventListener('click', function (e) {
    if (e.target === modalOverlay) closeModal();
});

diagnosisUlangBtn.addEventListener('click', function () {
    closeModal();
    // Reset form
    gejalaCheckboxes.forEach(cb => { cb.checked = false; });
    updateProgress();
});

// ============================================================
// TAMPILKAN HASIL
// ============================================================
function tampilkanHasil(data) {
    hasilData = data;
    window._hasilDiagnosis = data; // untuk fungsi cetak

    const isSeri   = data.is_seri === true;
    const utamaArr = isSeri ? data.diagnosis_utama : [data.diagnosis_utama];

    const colorMap = {
        'Gastritis': '#dc2626',
        'GERD':      '#d97706',
        'Dispepsia': '#16a34a'
    };

    // ── Header: nama penyakit ────────────────────────────────
    const namaEl = document.getElementById('hasilPenyakitNama');
    if (isSeri) {
        // Tampilkan semua nama yang seri sebagai badge-badge
        namaEl.innerHTML = utamaArr.map(u =>
            `<span style="display:inline-block;margin:0 4px;padding:2px 14px;
                border-radius:50px;font-size:1.1rem;font-weight:800;
                background:${colorMap[u.nama]||'#d92e67'}20;
                color:${colorMap[u.nama]||'#d92e67'};">${u.nama}</span>`
        ).join('<span style="font-size:1.2rem;color:#9ca3af;"> = </span>');
    } else {
        namaEl.textContent = utamaArr[0].nama;
    }

    // ── Probabilitas circle ──────────────────────────────────
    const prob     = parseFloat(utamaArr[0].probabilitas).toFixed(4);
    document.getElementById('hasilProbNumber').textContent = prob + '%';
    const circle = document.getElementById('hasilProbCircle');
    if (isSeri) {
        // Gradien jika seri
        const colors = utamaArr.map(u => colorMap[u.nama] || '#d92e67');
        circle.style.background = colors.length > 1
            ? `linear-gradient(135deg, ${colors.join(', ')})`
            : colors[0];
        circle.style.boxShadow = `0 6px 24px ${colors[0]}55`;
    } else {
        const c = colorMap[utamaArr[0].nama] || '#d92e67';
        circle.style.background = c;
        circle.style.boxShadow  = `0 6px 24px ${c}55`;
    }

    // ── Badge nama pasien ────────────────────────────────────
    const hasilBadge = document.getElementById('hasilBadge');
    if (hasilBadge && data.nama_pasien) {
        hasilBadge.textContent = '👤 Hasil untuk: ' + data.nama_pasien;
    }

    // ── Jika SERI: tampilkan info khusus seri ───────────────
    const deskripsiEl = document.getElementById('hasilDeskripsi');
    const saranEl     = document.getElementById('hasilSaran');

    if (isSeri) {
        deskripsiEl.innerHTML = utamaArr.map(u =>
            `<div style="margin-bottom:0.75rem;">
                <strong style="color:${colorMap[u.nama]||'#d92e67'};">${u.nama}:</strong>
                ${u.saran.deskripsi}
             </div>`
        ).join('');

        saranEl.innerHTML = '';
        utamaArr.forEach(u => {
            const header = document.createElement('li');
            header.style.cssText = 'font-weight:700;list-style:none;margin-top:0.5rem;'
                + `color:${colorMap[u.nama]||'#d92e67'};`;
            header.textContent = `— ${u.nama}:`;
            saranEl.appendChild(header);
            u.saran.saran.forEach(s => {
                const li = document.createElement('li');
                li.textContent = s;
                saranEl.appendChild(li);
            });
        });
    } else {
        const utama = utamaArr[0];
        deskripsiEl.textContent = utama.saran.deskripsi;
        saranEl.innerHTML = '';
        utama.saran.saran.forEach(s => {
            const li = document.createElement('li');
            li.textContent = s;
            saranEl.appendChild(li);
        });
    }

    // ── Prob bars ────────────────────────────────────────────
    const barColorMap = {
        'Gastritis': { bar: '#dc2626', bg: '#fee2e2', text: '#991b1b' },
        'GERD':      { bar: '#d97706', bg: '#fef3c7', text: '#92400e' },
        'Dispepsia': { bar: '#16a34a', bg: '#dcfce7', text: '#14532d' }
    };
    const probBars = document.getElementById('probBars');
    probBars.innerHTML = '';
    data.semua_hasil.forEach(item => {
        const pct    = parseFloat(item.probabilitas).toFixed(4);
        const pctNum = parseFloat(item.probabilitas);
        const c      = barColorMap[item.nama] || { bar: '#d92e67', bg: '#f9e8f0', text: '#6d082a' };
        // Tandai jika termasuk diagnosis utama seri
        const isSeriItem = isSeri && utamaArr.some(u => u.nama === item.nama);
        const div = document.createElement('div');
        div.className = 'prob-bar-item';
        div.innerHTML = `
            <span class="prob-bar-label" style="color:${c.text};font-weight:700;">
                ${item.nama}${isSeriItem ? ' 🏆' : ''}
            </span>
            <div class="prob-bar-track" style="background:${c.bg};">
                <div class="prob-bar-fill" style="width:0%;background:${c.bar};"
                    data-target="${pctNum}"></div>
            </div>
            <span class="prob-bar-pct" style="color:${c.text};">${pct}%</span>
        `;
        probBars.appendChild(div);
    });

    // ── Jumlah & daftar gejala ───────────────────────────────
    document.getElementById('hasilJumlahGejala').textContent = data.jumlah_gejala;
    const gejalaList = document.getElementById('hasilGejalaList');
    gejalaList.innerHTML = '';
    data.gejala_dipilih.forEach(g => {
        const span = document.createElement('span');
        span.className = 'gejala-tag-item';
        span.textContent = g.kode + ' — ' + g.nama.substring(0, 40) + (g.nama.length > 40 ? '...' : '');
        span.title = g.nama;
        gejalaList.appendChild(span);
    });

    // ── Switch loading → hasil ───────────────────────────────
    loadingState.style.display = 'none';
    hasilState.style.display   = 'block';

    // Animasi bar
    setTimeout(() => {
        document.querySelectorAll('.prob-bar-fill').forEach(bar => {
            bar.style.width = bar.getAttribute('data-target') + '%';
        });
    }, 100);
}

// ============================================================
// SUBMIT FORM — KIRIM KE BACKEND
// ============================================================
diagnosisForm.addEventListener('submit', function (e) {
    e.preventDefault();

    if (selectedGejala.length === 0) return;

    openModal();

    // Ambil waktu lokal perangkat pengguna
    const now = new Date();
    const pad = n => String(n).padStart(2, '0');
    const tanggal_client = `${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())}`;
    const waktu_client   = `${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;

    // Fetch ke Flask API
    fetch('/proses_diagnosis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ gejala: selectedGejala, tanggal_client, waktu_client })
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(err => { throw new Error(err.error || 'Terjadi kesalahan'); });
        }
        return response.json();
    })
    .then(data => {
        // Delay sedikit untuk efek loading
        setTimeout(() => {
            tampilkanHasil(data);
        }, 800);
    })
    .catch(err => {
        loadingState.innerHTML = `
            <div style="padding: 2rem; text-align: center; color: #c0392b;">
                <div style="font-size: 3rem; margin-bottom: 1rem;">⚠️</div>
                <p style="font-size: 1rem; font-weight: 600;">${err.message}</p>
                <button onclick="closeModal()" style="margin-top: 1.5rem; padding: 0.5rem 1.5rem; background: #1a6b4a; color: white; border: none; border-radius: 50px; cursor: pointer; font-family: inherit;">
                    Tutup
                </button>
            </div>
        `;
    });
});

// Di diagnosis.js, tambah fungsi ini
function kirimEmail() {
    const data = window._hasilDiagnosis;
    const utama = data.diagnosis_utama;
    const nama  = Array.isArray(utama) ? utama.map(u => u.nama).join(' & ') : utama.nama;
    const prob  = Array.isArray(utama) ? utama[0].probabilitas : utama.probabilitas;

    const subject = encodeURIComponent(`Hasil Diagnosis 3G-CARE — ${nama}`);
    const body = encodeURIComponent(
`HASIL DIAGNOSIS 3G-CARE
========================
Nama Pasien  : ${data.nama_pasien}
Tanggal      : ${new Date().toLocaleDateString('id-ID')}

DIAGNOSIS UTAMA
---------------
Penyakit     : ${nama}
Probabilitas : ${parseFloat(prob).toFixed(2)}%

PERBANDINGAN PROBABILITAS
--------------------------
${data.semua_hasil.map(h => `${h.nama.padEnd(12)}: ${parseFloat(h.probabilitas).toFixed(2)}%`).join('\n')}

GEJALA DILAPORKAN (${data.jumlah_gejala} gejala)
--------------------------
${data.gejala_dipilih.map(g => `• ${g.kode} — ${g.nama}`).join('\n')}

⚠️ PENTING: Hasil ini hanya bersifat referensi.
Segera konsultasikan ke dokter spesialis gastroenterologi.

3G-CARE — Sistem Pakar Penyakit Lambung`
    );

    window.location.href = `mailto:?subject=${subject}&body=${body}`;
}

// ============================================================
// KEYBOARD ESC UNTUK TUTUP MODAL
// ============================================================
document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeModal();
});

// ============================================================
// INIT
// ============================================================
updateProgress();
