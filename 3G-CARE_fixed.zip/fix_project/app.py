from flask import Flask, render_template, request, jsonify, session, redirect, url_for
import math
import sqlite3
import json
import os
from datetime import datetime, timezone, timedelta

app = Flask(__name__)
app.secret_key = 'sistem_pakar_lambung_2024'

# ============================================================
# DATABASE SETUP
# ============================================================
DB_PATH = os.path.join(os.path.dirname(__file__), 'riwayat.db')

def init_db():
    """Inisialisasi database dan buat tabel jika belum ada."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS riwayat_diagnosis (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama_pasien TEXT NOT NULL,
            nama_lengkap TEXT NOT NULL DEFAULT '',
            tanggal TEXT NOT NULL,
            waktu TEXT NOT NULL,
            gejala_dipilih TEXT NOT NULL,
            jumlah_gejala INTEGER NOT NULL,
            diagnosis_utama TEXT NOT NULL,
            probabilitas_utama REAL NOT NULL,
            semua_hasil TEXT NOT NULL
        )
    ''')
    # Migrasi: tambah kolom nama_lengkap jika belum ada (untuk DB lama)
    try:
        cursor.execute("ALTER TABLE riwayat_diagnosis ADD COLUMN nama_lengkap TEXT NOT NULL DEFAULT ''")
    except Exception:
        pass  # kolom sudah ada
    conn.commit()
    conn.close()

init_db()


def simpan_riwayat(nama_pasien, nama_lengkap, gejala_dipilih, jumlah_gejala, diagnosis_utama, probabilitas_utama, semua_hasil, tanggal_client=None, waktu_client=None):
    # Gunakan waktu dari client (browser) jika tersedia, fallback ke WIB server
    if tanggal_client and waktu_client:
        tgl = tanggal_client
        wkt = waktu_client
    else:
        WIB = timezone(timedelta(hours=7))
        sekarang = datetime.now(WIB)
        tgl = sekarang.strftime('%Y-%m-%d')
        wkt = sekarang.strftime('%H:%M:%S')
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO riwayat_diagnosis
            (nama_pasien, nama_lengkap, tanggal, waktu, gejala_dipilih, jumlah_gejala, diagnosis_utama, probabilitas_utama, semua_hasil)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        nama_pasien,   # email — untuk pencarian
        nama_lengkap,  # nama asli — untuk tampilan
        tgl,
        wkt,
        json.dumps(gejala_dipilih),
        jumlah_gejala,
        diagnosis_utama,
        probabilitas_utama,
        json.dumps(semua_hasil)
    ))
    conn.commit()
    conn.close()


def ambil_semua_riwayat():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM riwayat_diagnosis ORDER BY id DESC')
    rows = cursor.fetchall()
    conn.close()
    hasil = []
    for row in rows:
        hasil.append({
            'id': row['id'],
            'nama_pasien': row['nama_lengkap'] or row['nama_pasien'],
            'email_pasien': row['nama_pasien'],
            'tanggal': row['tanggal'],
            'waktu': row['waktu'],
            'gejala_dipilih': json.loads(row['gejala_dipilih']),
            'jumlah_gejala': row['jumlah_gejala'],
            'diagnosis_utama': row['diagnosis_utama'],
            'probabilitas_utama': row['probabilitas_utama'],
            'semua_hasil': json.loads(row['semua_hasil'])
        })
    return hasil

def ambil_riwayat_by_email(email):
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM riwayat_diagnosis WHERE nama_pasien = ? ORDER BY id DESC', (email,))
    rows = cursor.fetchall()
    conn.close()
    hasil = []
    for row in rows:
        hasil.append({
            'id': row['id'],
            'nama_pasien': row['nama_lengkap'] or row['nama_pasien'],  # tampilkan nama asli
            'email_pasien': row['nama_pasien'],
            'tanggal': row['tanggal'],
            'waktu': row['waktu'],
            'gejala_dipilih': json.loads(row['gejala_dipilih']),
            'jumlah_gejala': row['jumlah_gejala'],
            'diagnosis_utama': row['diagnosis_utama'],
            'probabilitas_utama': row['probabilitas_utama'],
            'semua_hasil': json.loads(row['semua_hasil'])
        })
    return hasil

def ambil_nama_by_email(email):
    """Ambil nama_lengkap dari record terbaru berdasarkan email."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute(
        'SELECT nama_lengkap FROM riwayat_diagnosis WHERE nama_pasien = ? ORDER BY id DESC LIMIT 1',
        (email,)
    )
    row = cursor.fetchone()
    conn.close()
    if row and row['nama_lengkap']:
        return row['nama_lengkap']
    return ''

def hapus_riwayat(id_riwayat):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('DELETE FROM riwayat_diagnosis WHERE id = ?', (id_riwayat,))
    conn.commit()
    conn.close()


def hapus_semua_riwayat():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('DELETE FROM riwayat_diagnosis')
    conn.commit()
    conn.close()


# ============================================================
# DATA PENYAKIT
# ============================================================
data_penyakit = {
    'P01': 'Gastritis',
    'P02': 'GERD',
    'P03': 'Dispepsia'
}

data_gejala = {
    'GP01': 'Heartburn, sensasi terbakar atau menyengat dari ulu hati ke dada, terkadang disertai rasa sakit seperti rasa nyeri yang pedih',
    'GP02': 'Regurgitasi, rasa asam dan pahit pada lidah dan rongga mulut sesaat setelah makan',
    'GP03': 'Mengalami Mual saat kondisi belum makan',
    'GP04': 'Muntah-muntah',
    'GP05': 'Cepat kenyang setelah sedikit makan',
    'GP06': 'Sendawa berlebihan',
    'GP07': 'Disfagia, sulit untuk menelan makanan',
    'GP08': 'Odinafagia, terasa nyeri dan sakit ketika menelan',
    'GP09': 'Hipersalivasi, produksi air liur yang berlebihan',
    'GP10': 'Rasa kembung pada saluran cerna atas',
    'GP11': 'Tenggorokan berlendir',
    'GP12': 'Rasa nyeri pada tengah perut bagian atas (epigastrium)',
    'GP13': 'Muntah darah (kondisi parah)',
    'GP14': 'Tinja berwarna gelap',
    'GP15': 'Tubuh terasa mudah lemah',
    'GP16': 'Pembengkakan di area perut',
    'GP17': 'Kulit pucat',
    'GP18': 'Keluar cairan dari lambung baik pada mulut ataupun hidung',
    'GP19': 'Keringat dingin',
    'GP20': 'Mengalami gejala anemia seperti kelelahan, pusing, jantung berdetak cepat',
    'GP21': 'Suara usus terdengar keras (borborigmi)',
    'GP22': 'Anoreksia, berkurangnya nafsu makan',
    'GP23': 'Berat badan yang menurun secara tiba-tiba',
    'GP24': 'Cegukan yang berlebihan dan berkepanjangan',
    'GP25': 'Muntah cairan asam atau muntah air',
    'GP26': 'Sering merasa dehidrasi',
    'GP27': 'Buang air besar (feses) yang terus-menerus',
    'GP28': 'Mengalami masalah pernapasan seperti batuk-batuk dan sesak napas'
}

# ============================================================
# RELASI GEJALA-PENYAKIT (Tabel 3.4 PDF)
# 1 = gejala berkaitan dengan penyakit, 0 = tidak
# Sumber: Tabel 3.3 Rule Penyakit → Tabel 3.4 Relasi
# ============================================================
# Gastritis (P01): GP03,GP04,GP05,GP12,GP13,GP14,GP15,GP16,GP17,GP19,GP20,GP22,GP23
# GERD      (P02): GP01,GP02,GP03,GP04,GP05,GP06,GP07,GP08,GP09,GP24,GP26,GP27,GP28
# Dispepsia (P03): GP01,GP03,GP04,GP05,GP06,GP10,GP11,GP12,GP18,GP21,GP22,GP24,GP25

relasi = {
    'GP01': {'P01': 0, 'P02': 1, 'P03': 1},
    'GP02': {'P01': 0, 'P02': 1, 'P03': 0},
    'GP03': {'P01': 1, 'P02': 1, 'P03': 1},
    'GP04': {'P01': 1, 'P02': 1, 'P03': 1},
    'GP05': {'P01': 1, 'P02': 1, 'P03': 1},
    'GP06': {'P01': 0, 'P02': 1, 'P03': 1},
    'GP07': {'P01': 0, 'P02': 1, 'P03': 0},
    'GP08': {'P01': 0, 'P02': 1, 'P03': 0},
    'GP09': {'P01': 0, 'P02': 1, 'P03': 0},
    'GP10': {'P01': 0, 'P02': 0, 'P03': 1},
    'GP11': {'P01': 0, 'P02': 0, 'P03': 1},
    'GP12': {'P01': 1, 'P02': 0, 'P03': 1},
    'GP13': {'P01': 1, 'P02': 0, 'P03': 0},
    'GP14': {'P01': 1, 'P02': 0, 'P03': 0},
    'GP15': {'P01': 1, 'P02': 0, 'P03': 0},
    'GP16': {'P01': 1, 'P02': 0, 'P03': 0},
    'GP17': {'P01': 1, 'P02': 0, 'P03': 0},
    'GP18': {'P01': 0, 'P02': 0, 'P03': 1},
    'GP19': {'P01': 1, 'P02': 0, 'P03': 0},
    'GP20': {'P01': 1, 'P02': 0, 'P03': 0},
    'GP21': {'P01': 0, 'P02': 0, 'P03': 1},
    'GP22': {'P01': 1, 'P02': 0, 'P03': 1},
    'GP23': {'P01': 1, 'P02': 0, 'P03': 0},
    'GP24': {'P01': 0, 'P02': 1, 'P03': 1},
    'GP25': {'P01': 0, 'P02': 0, 'P03': 1},
    'GP26': {'P01': 0, 'P02': 1, 'P03': 0},
    'GP27': {'P01': 0, 'P02': 1, 'P03': 0},
    'GP28': {'P01': 0, 'P02': 1, 'P03': 0},
}

# Jumlah gejala yang berkaitan dengan tiap penyakit
# P01: 13, P02: 13, P03: 13 gejala dari rule
TOTAL_GEJALA = len(data_gejala)  # 28

# ============================================================
# NAIVE BAYES CLASSIFIER — 8 LANGKAH
# ============================================================
def hitung_naive_bayes(gejala_dipilih):
    """
    Langkah 1 : Prior P(C) = 1/N_kelas  (Equal Prior)
    Langkah 2 : Likelihood P(xi|C) = (n_ic + α) / (N_c + α × k)
                n_ic = relasi gejala-penyakit (0 atau 1)
                N_c  = jumlah gejala terkait penyakit C
                α    = 0.001 (Lidstone smoothing)
                k    = 2 (biner: 0 atau 1)
    Langkah 3 : Likelihood gejala TIDAK dipilih P(xi=0|C) = 1 - P(xi=1|C)
    Langkah 4 : Skor(C) = P(C) × ∏ P(xi|C) untuk semua gejala dipilih
    Langkah 5 : P(X) = Σ Skor(C) untuk semua kelas
    Langkah 6 : Posterior P(C|X) = Skor(C) / P(X)
    Langkah 7 : Persentase = P(C|X) × 100%
    Langkah 8 : Diagnosis utama = kelas dengan persentase tertinggi
    """

    ALPHA   = 0.001   # Lidstone smoothing
    K       = 2       # jumlah kemungkinan nilai fitur (biner: 0 atau 1)
    N_KELAS = len(data_penyakit)

    # ----------------------------------------------------------
    # LANGKAH 1 — Prior Probability P(C)
    # Equal Prior karena tidak ada data populasi
    # P(C) = 1 / N_kelas = 1/3
    # ----------------------------------------------------------
    prior = {kp: 1.0 / N_KELAS for kp in data_penyakit}

    # ----------------------------------------------------------
    # LANGKAH 2 — Likelihood dengan Lidstone Smoothing
    # P(xi|C) = (n_ic + α) / (N_c + α × k)
    # N_c = jumlah gejala yang terkait (relasi=1) dengan penyakit C
    # ----------------------------------------------------------
    N_c = {
        kp: sum(relasi[g][kp] for g in relasi)
        for kp in data_penyakit
    }

    # Hitung likelihood untuk SETIAP gejala yang dipilih
    likelihood_dipilih = {}
    for kg in gejala_dipilih:
        if kg not in relasi:
            continue
        likelihood_dipilih[kg] = {}
        for kp in data_penyakit:
            n_ic = relasi[kg][kp]          # 0 atau 1
            likelihood_dipilih[kg][kp] = (n_ic + ALPHA) / (N_c[kp] + ALPHA * K)

    # ----------------------------------------------------------
    # LANGKAH 3 — Likelihood gejala TIDAK dipilih
    # P(xi=0|C) = 1 - P(xi=1|C)
    # ----------------------------------------------------------
    gejala_tidak_dipilih = [g for g in data_gejala if g not in gejala_dipilih]

    likelihood_tidak = {}
    for kg in gejala_tidak_dipilih:
        if kg not in relasi:
            continue
        likelihood_tidak[kg] = {}
        for kp in data_penyakit:
            n_ic  = relasi[kg][kp]
            p_ada = (n_ic + ALPHA) / (N_c[kp] + ALPHA * K)
            likelihood_tidak[kg][kp] = 1.0 - p_ada

    # ----------------------------------------------------------
    # LANGKAH 4 — Skor setiap penyakit
    # Skor(C) = P(C) × ∏ P(xi|C) gejala dipilih
    #                 × ∏ P(xi=0|C) gejala tidak dipilih
    # Gunakan log-sum untuk menghindari underflow numerik
    # ----------------------------------------------------------
    log_skor = {}
    for kp in data_penyakit:
        log_s = math.log(prior[kp])

        # Kalikan likelihood gejala yang DIPILIH
        for kg in gejala_dipilih:
            if kg in likelihood_dipilih:
                log_s += math.log(likelihood_dipilih[kg][kp])

        # Kalikan likelihood gejala yang TIDAK DIPILIH
        for kg in gejala_tidak_dipilih:
            if kg in likelihood_tidak:
                val = likelihood_tidak[kg][kp]
                if val > 0:
                    log_s += math.log(val)

        log_skor[kp] = log_s

    skor = {kp: math.exp(log_skor[kp]) for kp in data_penyakit}

    # ----------------------------------------------------------
    # LANGKAH 5 — Probabilitas gabungan seluruh evidence P(X)
    # P(x1, x2, ..., xn) = Σ Skor(C) untuk semua C
    # ----------------------------------------------------------
    p_evidence = sum(skor.values())

    # ----------------------------------------------------------
    # LANGKAH 6 — Posterior Probability P(C|X)
    # P(C|x1,...,xn) = Skor(C) / P(x1,...,xn)
    # ----------------------------------------------------------
    posterior = {}
    for kp in data_penyakit:
        posterior[kp] = skor[kp] / p_evidence if p_evidence > 0 else 0.0

    # ----------------------------------------------------------
    # LANGKAH 7 — Persentase posterior setiap penyakit
    # ----------------------------------------------------------
    persentase = {kp: round(posterior[kp] * 100, 4) for kp in data_penyakit}

    # ----------------------------------------------------------
    # LANGKAH 8 — Diagnosis utama = nilai persentase tertinggi
    # ----------------------------------------------------------
    return sorted(persentase.items(), key=lambda x: x[1], reverse=True)

# ============================================================
# SARAN DAN PENANGANAN
# ============================================================
saran_penyakit = {
    'P01': {
        'deskripsi': 'Gastritis adalah peradangan pada lapisan lambung yang dapat menyebabkan rasa nyeri, mual, dan muntah.',
        'penyebab': ['Infeksi bakteri H. pylori', 'Penggunaan obat anti-inflamasi berlebihan', 'Konsumsi alkohol berlebihan', 'Stres berat', 'Pola makan tidak teratur'],
        'saran': ['Hindari makanan pedas, asam, dan berlemak', 'Makan dalam porsi kecil namun sering (5-6 kali sehari)', 'Hindari konsumsi alkohol dan rokok', 'Kelola stres dengan baik', 'Konsumsi antasida sesuai anjuran dokter', 'Segera konsultasi ke dokter']
    },
    'P02': {
        'deskripsi': 'GERD adalah kondisi dimana asam lambung naik ke kerongkongan secara berulang, menyebabkan iritasi dan heartburn persisten.',
        'penyebab': ['Melemahnya katup LES', 'Obesitas', 'Kehamilan', 'Hernia hiatal', 'Pola makan tidak sehat'],
        'saran': ['Hindari makan 2-3 jam sebelum tidur', 'Tinggikan kepala tempat tidur 15-20 cm', 'Hindari coklat, kafein, alkohol, makanan berlemak', 'Pertahankan berat badan ideal', 'Hindari pakaian terlalu ketat', 'Konsultasi dokter untuk terapi PPI']
    },
    'P03': {
        'deskripsi': 'Dispepsia adalah sekumpulan gejala gangguan pencernaan bagian atas meliputi rasa tidak nyaman, kembung, cepat kenyang, dan mual.',
        'penyebab': ['Pola makan tidak teratur', 'Stres dan kecemasan', 'Konsumsi obat-obatan tertentu', 'Infeksi H. pylori', 'Intoleransi makanan'],
        'saran': ['Atur pola makan secara teratur', 'Kunyah makanan perlahan', 'Hindari makan berlebihan', 'Kurangi kafein dan minuman bersoda', 'Olahraga ringan secara teratur', 'Konsultasi dokter untuk endoskopi jika diperlukan']
    }
}


# ============================================================
# ROUTES
# ============================================================

@app.route('/')
def index():
    # Jangan clear session agar data profil tetap ada saat kembali ke beranda
    return render_template('index.html',
        session_nama=session.get('nama',''),
        session_email=session.get('email',''),
        session_umur=session.get('umur','')
    )

@app.route('/diagnosis')
def diagnosis():
    # Jika belum isi identitas, redirect ke beranda
    if not session.get('email') or not session.get('nama'):
        return redirect(url_for('index'))
    return render_template('diagnosis.html', gejala=data_gejala)

@app.route('/mulai_diagnosis', methods=['POST'])
def mulai_diagnosis():
    session['email'] = request.form.get('email', '').strip()
    session['nama']  = request.form.get('nama', '').strip()
    session['umur']  = request.form.get('umur', '').strip()
    return redirect(url_for('diagnosis'))

@app.route('/update_profil', methods=['POST'])
def update_profil():
    data = request.get_json()
    if data.get('nama'):  session['nama']  = data['nama'].strip()
    if data.get('email'): session['email'] = data['email'].strip()
    if data.get('umur'):  session['umur']  = data['umur'].strip()
    return jsonify({'success': True,
                    'nama': session.get('nama',''),
                    'email': session.get('email','')})

@app.route('/proses_diagnosis', methods=['POST'])
def proses_diagnosis():
    data = request.get_json()
    gejala_dipilih = data.get('gejala', [])
    tanggal_client = data.get('tanggal_client', None)
    waktu_client   = data.get('waktu_client', None)

    # Ambil data dari session
    nama_pasien  = session.get('nama', 'Anonim')
    email_pasien = session.get('email', 'anonim@unknown.com')

    if len(gejala_dipilih) == 0:
        return jsonify({'error': 'Pilih minimal satu gejala'}), 400

    hasil_nb = hitung_naive_bayes(gejala_dipilih)
    prob_tertinggi = hasil_nb[0][1]

    # Deteksi seri: semua penyakit dengan probabilitas == tertinggi
    utama_list = [
        (kp, p) for kp, p in hasil_nb
        if round(p, 4) == round(prob_tertinggi, 4)
    ]

    detail_gejala = [{'kode': k, 'nama': data_gejala[k]} for k in gejala_dipilih if k in data_gejala]
    hasil_lengkap = [
        {'kode': kp, 'nama': data_penyakit[kp], 'probabilitas': round(p, 4), 'saran': saran_penyakit[kp]}
        for kp, p in hasil_nb
    ]

    # Simpan ke DB — jika seri, simpan semua nama penyakit digabung
    nama_utama_db = ' & '.join([data_penyakit[kp] for kp, _ in utama_list])
    simpan_riwayat(
        nama_pasien=email_pasien,
        nama_lengkap=nama_pasien,
        gejala_dipilih=detail_gejala,
        jumlah_gejala=len(gejala_dipilih),
        diagnosis_utama=nama_utama_db,
        probabilitas_utama=round(prob_tertinggi, 4),
        semua_hasil=hasil_lengkap,
        tanggal_client=tanggal_client,
        waktu_client=waktu_client
    )

    # Jika hanya 1 diagnosis utama → format lama (backward compatible)
    # Jika seri → kirim list diagnosis_utama
    if len(utama_list) == 1:
        kp, p = utama_list[0]
        diagnosis_utama_resp = {
            'kode': kp,
            'nama': data_penyakit[kp],
            'probabilitas': round(p, 4),
            'saran': saran_penyakit[kp]
        }
    else:
        diagnosis_utama_resp = [
            {'kode': kp, 'nama': data_penyakit[kp],
             'probabilitas': round(p, 4), 'saran': saran_penyakit[kp]}
            for kp, p in utama_list
        ]

    return jsonify({
        'diagnosis_utama': diagnosis_utama_resp,
        'is_seri': len(utama_list) > 1,
        'semua_hasil': hasil_lengkap,
        'gejala_dipilih': detail_gejala,
        'jumlah_gejala': len(gejala_dipilih),
        'nama_pasien': nama_pasien
    })

@app.route('/riwayat')
def riwayat():
    # Prioritas: URL query param → session
    email_query = request.args.get('email', '').strip() or session.get('email', '')

    if not email_query:
        return render_template('riwayat.html', riwayat=[], email_query='', nama_aktif='')

    data_riwayat = ambil_riwayat_by_email(email_query)

    # Ambil nama dari: session → DB (nama_lengkap) → fallback email
    nama_aktif = (
        session.get('nama', '') or
        ambil_nama_by_email(email_query) or
        email_query
    )

    return render_template('riwayat.html', riwayat=data_riwayat, email_query=email_query, nama_aktif=nama_aktif)

@app.route('/api/riwayat', methods=['GET'])
def api_riwayat():
    email_aktif = session.get('email')
    if not email_aktif:
        return jsonify({'error': 'Unauthorized'}), 401
    data_riwayat = ambil_riwayat_by_email(email_aktif)
    return jsonify({'riwayat': data_riwayat, 'total': len(data_riwayat)})

@app.route('/api/riwayat/<int:id_riwayat>', methods=['DELETE'])
def api_hapus_riwayat(id_riwayat):
    # Ambil email dari session ATAU query param (?email=...)
    email_aktif = (
        session.get('email') or
        request.args.get('email', '').strip()
    )
    if not email_aktif:
        return jsonify({'error': 'Unauthorized'}), 401
    hapus_riwayat(id_riwayat)
    return jsonify({'success': True, 'message': f'Riwayat #{id_riwayat} berhasil dihapus'})

@app.route('/api/riwayat/hapus-semua', methods=['DELETE'])
def api_hapus_semua():
    # Ambil email dari session ATAU query param (?email=...)
    email_aktif = (
        session.get('email') or
        request.args.get('email', '').strip()
    )
    if not email_aktif:
        return jsonify({'error': 'Unauthorized'}), 401
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('DELETE FROM riwayat_diagnosis WHERE nama_pasien = ?', (email_aktif,))
    conn.commit()
    conn.close()
    return jsonify({'success': True, 'message': 'Semua riwayat berhasil dihapus'})

@app.route('/hasil')
def hasil():
    return render_template('hasil.html')

@app.route('/tentang')
def tentang():
    return render_template('tentang.html')

if __name__ == '__main__':
    app.run(debug=True, port=5000)
